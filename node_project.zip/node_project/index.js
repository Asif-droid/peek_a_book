const morgan=require("morgan");
const express=require("express");
//const oracle=require("oracledb");


const fs=require('fs');

const router=require("express-promise-router")();
var bodyParser = require('body-parser');

const cors=require('cors');     //for cross referencing


const logger=require('./funtions');
const { json } = require("express");

//oracle.outFormat = oracle.OBJECT;
 

///for hbs




router.get("/employee/all", async function(req,res,next){
    console.log("started");
    var query="select * from employees ";
    var params=[];
    let result=await logger.log(query,params);
    //console.log(result);

    //res.sendFile(__dirname+'/front/home.html',json(result));

    res.status(200).json(result);
    //logger.log("hello")
});
router.get('/employee',async function(req,res,next){
    //console.log(__dirname)



    console.log("started");
    var query=' SELECT  FIRST_NAME  from EMPLOYEES ';
    var params=[];
    let result=await logger.log(query,params);
    //console.log(result);

    //res.sendFile(__dirname+'/front/home.html',json(result));
    //var jr=json(result);
    //console.log(result);

    //res.status(200).json(result);

    
    res.render('emp',{d:result,w:[{a:"s"},{a:"sm"},{a:"sa"},{a:"se"}]});
    
    

});
router.get('/test/:o',(req,res,next)=>{
    var q=JSON.parse(req.params.o);
    //console.log(q);
    res.status(200).json(q.i);
})



router.get('/last_name/highst_sal',async function(req,res,next){
    console.log("started");
    var query="  select e.last_name, d.department_name,e.salary from EMPLOYEES e join (select department_id,max(salary) mxs from EMPLOYEES group by department_id) d1 on(e.department_id=d1.department_id) join DEPARTMENTS d on(e.department_id=d.department_id) where e.salary=d1.mxs order by d1.mxs";
    var params=[];
    let result=await logger.log(query,params);
    //console.log(result);

    res.status(200).json(result);
})
router.get('/',function(req,res,next){
    //console.log(__dirname)



    res.sendFile(__dirname+'/front/index.html')
    

});
router.get('/home',function(req,res,next){
    //console.log(__dirname)



    res.render('home2');
    

});


router.get('/books',async function(req,res,next){
    //console.log(__dirname)
    //console.log("started");
    var sid=req.query.sid;
    console.log(sid);
    var query='SELECT "id","name","genre" FROM "books" where "publisher_id"='+sid;
    var params=[];
    let result=await logger.log(query,params);
    //console.log(result);

    //res.sendFile(__dirname+'/front/home.html',json(result));

    res.status(200).json(result);

    //console.log(req);
    //res.sendFile(__dirname+'/front/home.html')
    

});
router.get('/shops',async function(req,res,next){
    //console.log(__dirname)
    //console.log("started");
    var query='SELECT "id","name" from "Shop_owner"';
    var params=[];
    let result=await logger.log(query,params);
    //console.log(result);

    //res.sendFile(__dirname+'/front/home.html',json(result));

    res.status(200).json(result);

    //console.log(req);
    //res.sendFile(__dirname+'/front/home.html')
    

});

router.get('/authors',async function(req,res,next){
    //console.log(__dirname)
    //console.log("started");
    var query='SELECT "name" from "Author"';
    var params=[];
    let result=await logger.log(query,params);
    //console.log(result);

    //res.sendFile(__dirname+'/front/home.html',json(result));

    res.status(200).json(result);

    //console.log(req);
    //res.sendFile(__dirname+'/front/home.html')
    

});


router.get('/login',function(req,res,next){
    res.render('login',{d:{user:'12'}});
})



router.get('/selected',function(req,res,next){
    
    //res.render('t1',{d:req.params});
    var q=(req.query);

    //res.status(200).json(q.shop);
    res.render('shop',{s:q});

})

router.get('/selectedbook',function(req,res,next){
    
    //res.render('t1',{d:req.params});
    var q=(req.query);
    console.log(q);

    //res.status(200).json(q.shop);
    res.render('prdet');

})

router.get('/t',(req,res,next)=>{
    res.render('shop');
})


router.post('/loginId',async(req,res,next)=>{
    var rq=req.params.obj;
    //console.log(rq.u);
    
    var user=req.body;
    console.log(user.id);
    
    var query='SELECT "name","pass" from "customer" WHERE "pass" ='+"'"+ user.pass +"'";
    var params=[];
    let result=await logger.log(query,params);
    //var jr=await result.json()
    var v;
    var r;
    
    if(result == undefined){
        v=false
    }
    
    else{
         r=result[0];
         console.log(r);
    }
    //console.log(r.FIRST_NAME);
    if(r === undefined){
        v=false;
    }
    else if(user.user==r.name){
        v=true;
    }
    else{
        v =false;
    }

    if(v){
        res.render('home2',{d:r});
    }
    else{
        //res.render('fail');
    }
    //res.status(200).json(req.body.user);
})

router.get('/books/:cat',async function(req,res,next){
    //console.log(__dirname)
    var cat=req.params.cat;

    res.status(200).json(cat);
   // console.log(__dirname);

});

const verify=async(user)=>{
    var query=' SELECT FIRST_NAME, LAST_NAME FROM EMPLOYEES WHERE EMPLOYEE_ID ='+user.pass;
    var params=[];
    let result=await logger.log(query,params);
    //var jr=await result.json()

    console.log(result[0].FIRST_NAME);
    if(user.user==result[0].FIRST_NAME){
        return true;
    }
    else{
        return false;
    }



}









const app=express();
app.use(cors());            //cross reference
app.options('*',cors());    //cross reference

//static
app.use(express.static('front'));
app.use('./css',express.static(__dirname+'front/css'));
app.use('./js',express.static(__dirname+'front/js'));
//app.use('./css',express.static(__dirname+''))F:\databaseProject\node_project\front\css


//for hbs

app.set('view engine','hbs');

app.use(bodyParser.urlencoded({ extended: true }));




app.use(express.json());
app.use(morgan("dev"));
app.use(router);
app.listen(8080,()=>{
    console.log("listening");
});